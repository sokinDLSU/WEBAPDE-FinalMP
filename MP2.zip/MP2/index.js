//index.js

const express = require("express")
const bodyparser = require("body-parser")
const session = require("express-session")
const cookieparser = require("cookie-parser")
const mongoose = require("mongoose")
const multer = require('multer');
const fs = require('fs');
const {User} = require("./user.js")
//const {Image} = require("./image.js")
const {Item} = require("./item.js")
//const cloudinary = require("cloudinary");
//const cloudinaryStorage = require("multer-storage-cloudinary");

var upload = multer({ dest: './public/images/'})

const app = express()
let idnum = 0

/*cloudinary.config({
    cloud_name: process.env.CLOUD_NAME,
    api_key: process.env.API_KEY,
    api_secret: process.env.API_SECRET
});
const storage = cloudinaryStorage({
    cloudinary: cloudinary,
    folder: "demo",
    allowedFormats: ["jpg", "png"],
    transformation: [{ width: 500, height: 500, crop: "limit" }]
});*/
mongoose.Promise = global.Promise
mongoose.connect("mongodb://localhost:27017/usersmp2",{
    useNewUrlParser : true 
})
const urlencoder = bodyparser.urlencoded({
    extended: false
})

app.use(express.static(__dirname + "/public"))
app.use(session({
    secret: "mp2",
    name: "cookie",
    resave: true,
    saveUninitialized: true,
    cookie:{
        maxAge: 1000*60*60*24*365
    }
}))

//handlebars.registerHelper('getimg', function(fn) {
//    return new Handlebars.SafeString();
//});

app.post("/register", urlencoder, (req,res)=>{
    let email = req.body.em
    let username = req.body.un
    let password = req.body.pw
    let address = req.body.ad
    let number = req.body.nm
    let user = new User({
        email,username,password,address,number
    })
    User.findOne({
        username: username
    },(err,doc)=>{
        if(err){
            res.send(err)
        }   
        else if(!doc){
            user.save().then((doc)=>{
                console.log(doc)
                req.session.username = doc.username
                res.redirect("/")

            },
            (error)=>{
                res.send(err)
            })
        }
        else{
            res.send("User already exists.")
            
        }
    })
})
app.post("/newitem",upload.single('image'), urlencoder, (req,res)=>{
    let name = req.body.name
    let location = req.body.location
    let date  = new Date().toLocaleDateString()
    let realdate  = new Date()
    let price = req.body.price*(1.01)/(1.01)
    let category = req.body.category
    let description = req.body.description
    var owner = ""
    let username = req.body.username
    var i=0
    
    
    console.log(req.file) // to see what is returned to you
    let image = new Object()
    let buff =fs.readFileSync(req.file.path)
    image.data = new Buffer(buff).toString('base64')
    image.path=req.file.path
    image.contenttype="image/png"
    
    
    User.findOne({
        username: username
    },(err,doc)=>{
        if(err){
            res.send(err)
        }
        else{
            owner = doc.username
            let item = new Item({
                name,location,date,realdate,price,category,description,owner,image
            })
            item.save().then((doc)=>{
                console.log(doc)
                res.redirect("/")
            },
            (error)=>{
                res.send(err)
            })
        }
    })
})
app.post("/updateitem",upload.single('image'), urlencoder, (req,res)=>{
    let name = req.body.name
    let location = req.body.location
    let price = req.body.price
    let category = req.body.category
    let description = req.body.description
    let image = new Object()
    if(req.file){
        let buff =fs.readFileSync(req.file.path)
        image.data = new Buffer(buff).toString('base64')
        image.path=req.file.path
        image.contenttype="image/png"

    
        Item.update({
            _id : req.body.id
        },{ 
            name:name,
            location:location,
            price:price,
            category:category,
            description:description,
            image:image
        }, (err,doc)=>{
            if(err){
                res.send(err)

            }else{
                //alert.("Item edited.")
                res.redirect("/")

            }
        })
    }
    else{
        Item.update({
            _id : req.body.id
        },{ 
            name:name,
            location:location,
            price:price,
            category:category,
            description:description,
        }, (err,doc)=>{
            if(err){
                res.send(err)

            }else{
                //alert.("Item edited.")
                res.redirect("/")

            }
        })
    }
    

})

app.use(cookieparser())


app.get("/", (req,res)=>{

    if(req.session.username){
        Item.find({}).sort({realdate: 'desc'}).exec(function(err,docs){
            if(err){
                res.send(err)
            }
            else{
                res.render("home.hbs",{
                    items:docs,
                    username: req.session.username
                })
            }
        })
    }else{
        res.sendFile(__dirname + "/public/login.html")
    }
})
app.get("/signout", (req,res)=>{
    req.session.username = null
    res.sendFile(__dirname + "/public/login.html")
})
app.get("/signup", (req,res)=>{
    if(req.session.username){
        res.redirect("/")
    }else{
        res.render("Signup.hbs")
    }
})




//******************************************
app.get("/itemlist", (req,res)=>{
    console.log("GET /items")
    Item.find({},(err,docs)=>{
        if(err){
            res.send(err)
        }
        else{
            res.render("home.hbs",{
                item:docs,
                username: req.session.username
            })
        }
    })
})


app.get("/additem", (req,res)=>{
    console.log(req.session.username)
    res.render("additem.hbs",{
            username: req.session.username
        })
})
app.get("/edititem", (req,res)=>{
    console.log(req.session.username)
    Item.findOne({
        _id: req.query.id
    },(err,doc)=>{
        if(err){
            res.send(err)
        }
        else{
            console.log(doc)
            res.render("edititem.hbs",{
                item:doc,
                username: req.session.username
            })
        }
    })
})
app.post("/deleteitem",urlencoder,(req,res)=>{
    Item.deleteOne({
        _id : req.body.id
    }, (err,doc)=>{
        if(err){
            res.send(err)
            
        }else{
            res.redirect("/")
        }
    })
})
app.get("/itemlistsortedbydate", (req,res)=>{
    console.log("GET /itemlistsortedbydate")

    Item.find({}).sort({realdate: 'desc'}).exec(function(err,docs){
    if(err){
            res.send(err)
        }
        else{
            res.render("home.hbs",{
                items:docs,
                username: req.session.username
            })
        }
    })
})
app.get("/itemlistsortedbycheapest", (req,res)=>{
    console.log("GET /itemlistsortedbycheapest")
    Item.find({}).sort({price: 'asc'}).exec(function(err,docs){
    if(err){
            res.send(err)
        }
        else{
            res.render("home.hbs",{
                items:docs,
                username: req.session.username
            })
        }
    })

})
app.get("/itemlistsortedbyexpensive", (req,res)=>{
    console.log("GET /itemlistsortedbyexpensive")
    Item.find({}).sort({price: 'desc'}).exec(function(err,docs){
    if(err){
            res.send(err)
        }
        else{
            res.render("home.hbs",{
                items:docs,
                username: req.session.username
            })
        }
    })

})
app.get("/myitems", (req,res)=>{
    console.log("GET /myitems")
    Item.find({
        owner: req.session.username
    },(err,docs)=>{
        if(err){
            res.send(err)
        }
        else{
            res.render("home.hbs",{
                items:docs,
                username: req.session.username
            })
        }
    })
})
app.post("/search",urlencoder, (req,res)=>{
    console.log("POST /search")
    let search = req.body.search
    Item.find({
        name:{
            "$regex":search, "$options":"i"
        }
    },(err,docs)=>{
        if(err){
            res.send(err)
        }
        else{
            res.render("home.hbs",{
                items:docs,
                username: req.session.username
            })
        }
    })
})
//******************************************

app.get("/item", (req,res)=>{
    console.log("GET /item")
    var owner = "asd"
    var uo = ""
    var num = ""
    var em = ""
    Item.findOne({
        _id: req.query.id
    },(err,doc)=>{
        if(err){
            res.send(err)
        }
        else{
            console.log(doc)
            owner = doc.owner
            User.findOne({
                username: owner
            },(err,doc)=>{
                if(err){
                    res.send(err)
                }
                else{
                    console.log(doc)
                    uo = owner
                    num = doc.number
                    em = doc.email
                    Item.findOne({
                        _id: req.query.id
                    },(err,doc)=>{
                        if(err){
                            res.send(err)
                        }
                        else{
                            if(owner==req.session.username){
                                res.render("myitem.hbs",{
                                    item:doc,
                                    userowner: uo,
                                    number: num,
                                    email: em,
                                    username: req.session.username
                                })
                               
                            }
                            else{
                                res.render("item.hbs",{
                                    item:doc,
                                    userowner: uo,
                                    number: num,
                                    email: em,
                                    username: req.session.username
                                })
                            }

                        }
                    })
                }
            })   
        }
    })
    console.log(owner)

    /*
    console.log(req.query.id)
    Item.findOne({
        _id: req.query.id
    },(err,doc)=>{
        if(err){
            res.send(err)
        }
        else{
            console.log(doc)
            res.render("item.hbs",{
                username: req.session.username,
                item:doc
            })
        }
    })*/
})






app.post("/login", urlencoder, (req,res)=>{
    let username = req.body.un
    let password = req.body.pw
    User.findOne({
        username: username,
        password: password
    },(err,doc)=>{
        if(err){
            res.send(err)
        }   
        else if(!doc){
            res.send("User doesn't exist/password is incorrect.")
            
        }
        else{
            console.log(doc)
            req.session.username = doc.username
            res.redirect("/")
        }
    })
})


app.listen(3000, function(){
    console.log("Live at port 3000")
})