
const mongoose = require("mongoose")


let Image = mongoose.model("image", {
    data: Buffer,
    contenttype:String,
    path:String,
    itemname:String
})


module.exports = {
    Image
}

