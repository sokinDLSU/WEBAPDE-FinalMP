
const mongoose = require("mongoose")


let Image = {data: Buffer, contenttype:String, path:String}
let Item = mongoose.model("item", {
    name: String,
    location: String,
    date: String,
    realdate:Date,
    price: Number,
    category: String,
    description: String,
    owner: String,
    image:Image
    //imageB:{ data: Buffer, contenttype:String},
    //imageC:{ data: Buffer, contenttype:String},
})

module.exports = {
    Item
}

