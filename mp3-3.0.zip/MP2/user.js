// filename : user.js
const mongoose = require("mongoose")

let User = mongoose.model("user", {
    email: String,
    username: String,
    password: String,
    address: String,
    number: String
})

module.exports = {
    User
}